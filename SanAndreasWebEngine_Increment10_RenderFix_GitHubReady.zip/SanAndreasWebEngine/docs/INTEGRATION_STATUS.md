# Integration status — Increment 09 real-file validation

The current working baseline consolidates the initial GitHub-ready project and available increments 02, 03, 05, 06, 07 and 08. No Increment 04 archive was present in the saved files. Increment 06 supersedes the earlier Increment 05 handling parser because it corrects the classic-PC row width from 37 to 36 fields.

## Runtime integration status

- `src/main.ts` runs the Three.js renderer, current world streamer, basic third-person movement and Increment 07 car-driving slice.
- `BrowserEngineRuntime`, `LocalAssetStreamer` and `RapierPhysicsWorld` exist, but are not yet the sole integrated runtime path in `main.ts`. The active world prototype still uses its simpler ground/raycast behavior.
- `gta.dat`, IMG, IDE and IPL data are indexed locally. The supplied `data.rar` plus `anim.rar` test set produced 4 readable IMG archives (`carrec.img`, `script.img`, `anim.img`, `cuts.img`), 14,205 IDE definitions and 9,315 map placements. The only manifest warning was the missing `models/cutscene.img`, which was not part of the two uploaded archives.
- Increment 07 adds a first local DFF/TXD car loader and handling-driven driving loop. It has no wheel contact, suspension, per-wheel grip, vehicle impact/deformation, full vehicle classes or traffic AI.
- Increment 03 SCM modules decode instructions/signatures only. There is no mission scheduler, VM or opcode execution engine.

## Increment 08 — ANP3 animation foundation

- Added a bounds-checked ANP3 IFP reader, compressed rotation and root translation decoding, local/IMG package indexing and quaternion/translation sampling.
- Sampling can be keyed by HAnim bone ID, but is not yet connected to a parsed DFF skeleton. CJ/ped animation is not yet available in the live game loop.

## Increment 09 — retail-format file validation and corrections

- Supplied `anim/ped.ifp` validated as ANP3: 294 clips, 7,607 tracks and 112,150 keyframes; all clip byte totals matched and the parser reached the declared end exactly.
- All 132 IFP entries in `anim/anim.img` validated as ANP3: 1,557 clips, 38,825 tracks and 868,337 keyframes. Combined total: 1,851 clips, 46,432 tracks and 980,487 keyframes.
- Corrected translation scale to 1/4096, stopped fixed-width names at the first NUL while preserving leading spaces, checked the animation frame-data byte total, and restricted decoding to observed type 3 and type 4 records. Unknown layouts are not guessed.
- Average raw quaternion magnitude across all 980,487 keyframes was 0.999830 before normalization. This supports the 1/4096 quaternion scale. Time values use the observed 1/60 scale.
- `cuts.img` contains 148 `.ifp`, 148 `.cut` and 148 `.dat` entries. Its IFP entries use `ANPK`, not ANP3; the ANP3 reader rejects them explicitly. A separate ANPK/cutscene implementation is still required.

## Still incomplete

- The player visual is not CJ. DFF Skin/HAnim hierarchy extraction, skeleton binding, IFP playback in the render loop and CJ clothing are missing.
- Native DFF pipelines, multiple RenderWare plugins, full TXD palette/raster handling, COL1, full collision response and all IPL/LOD/interior behaviors remain incomplete.
- Pedestrian/traffic AI, weapons/combat, wanted level/police, SCM mission execution, cutscenes, audio/radio, HUD/radar and save/load are not complete.
- The supplied archives do not include the main `models` directory or `models/cutscene.img`; the game loader still expects the user to select their complete local installation when eventually validating the 3D world.

## Verification boundary

- Strict standalone TypeScript compilation passed for the IFP parser and the local file-indexing/parser dependency set. A Node smoke test against the supplied `ped.ifp` and `anim.img` decoded every ANP3 package and reported zero failures among the 132 `anim.img` IFP entries.
- Synthetic Vitest fixtures are present, but the full Vitest suite and production Vite build were not run here because the project dependencies were not installed in this environment. They must still be run in Codespaces.
- The real-file checks validate container structure and parser accounting. They do not prove skeletal rendering, animation retargeting, game behavior parity or a complete playable game.

The supplied proprietary game archives remain outside this source package. They are indexed locally and are not uploaded to a server or included in the public repository.


## Increment 10 — rendering correction pass

- Removed the visible fallback plane which overlapped the Ganton world surface.
- Corrected quaternion basis conversion to match the `(x, y, z) -> (x, z, -y)` position conversion.
- Corrected missing DFF normals and UV channels so the renderer no longer installs zero-filled attributes.
- Made TXD failures non-fatal for DFF geometry.
- World diagnostics now distinguish visible mesh instances, rendered mesh count, cache count, missing/failed/empty DFFs, native geometry, collision meshes, model warnings, and unresolved IPL references.
- Current `data.rar` parser audit: 59 IDE files, 14,205 unique IDE definitions, 53 IPL files, 9,315 placements, 112 GTA.DAT resources, no manifest issues; 453 placements within 440 world units of the current Ganton spawn and no unresolved IDE IDs.
- The current working copy of `data.rar` has no IMG/DFF/TXD/IFP/COL payloads, so full 3D model rendering must still be tested against the user's complete local installation.
- Standalone parser compilation and synthetic DFF checks passed. Full app type-check, Vitest, and Vite production build remain blocked until the npm dependencies are installed.
