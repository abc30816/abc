# Increment 08 — ANP3 IFP animation foundation

## Scope

This increment adds an independently written, bounds-checked decoder for the San Andreas `ANP3` IFP container, a local package lookup layer, and a deterministic keyframe sampler. It is a data-format milestone, not a complete character animation system.

## What is implemented

- Reads the `ANP3` signature, package header, animation records and bone-sequence records.
- Decodes compressed rotation frames (type 3) and compressed root rotation/translation frames (type 4).
- Normalizes decoded quaternions and converts compressed time ticks (60 ticks per second) and root translations (1/4096 units) into runtime units. The translation scale was corrected and validated against the supplied real ANP3 files in Increment 09.
- Supports only frame types 3 and 4 observed in the supplied San Andreas ANP3 files. Other frame types are rejected rather than assigned a guessed size or meaning.
- Rejects invalid counts, unknown frame types, zero-length quaternions, non-monotonic frame times, truncated records and out-of-bounds declared ends.
- Samples a sequence with quaternion spherical interpolation and linear translation interpolation. Looping and clamped sampling are supported.
- Indexes loose `anim/*.ifp` packages and IFP entries found inside IMG archives. Packages are read and parsed only when requested; game files remain local in the browser.

## Not implemented by this increment

- ANPK/legacy IFP variants.
- Uncompressed animation keyframe formats.
- Full DFF Skin/HAnim hierarchy, bone binding, hierarchy retargeting or root-motion policy.
- Animation state graph, locomotion blending, upper-body overlays, facial animation or in-game event callbacks.
- DFF skeleton attachment and visible retail character playback. Increment 09 adds structural validation against the supplied `ped.ifp` and all 132 ANP3 entries in `anim.img`; this validates the package reader, not the final rendered pose.

## Format investigation and licensing discipline

This repository contains an independent TypeScript implementation. The supplied user-owned files were used as local binary test inputs only; no proprietary animation bytes are copied into the source repository. The implementation does not import or execute third-party tools.

## Tests added

- Compressed root and child track decoding.
- Quaternion normalization and pose sampling.
- Unknown frame type rejection and declared frame-data byte accounting.
- Looping/clamped sampling.
- Unsupported signature and frame-kind rejection.
- Monotonic time validation and truncated-payload rejection.
- Local loose IFP indexing.

## Next dependent milestone

Implement RenderWare skin/HAnim data extraction in DFF files, construct a named skeleton, map IFP sequence names/bone IDs to skeleton nodes, and apply sampled local transforms in the Three.js animation update loop. Only then does this format reader produce visible CJ/ped animation in the game.
