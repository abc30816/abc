# Increment 09 — real ANP3 IFP validation

## Input inventory

The supplied `anim.rar` archive contained `anim/ped.ifp` (1,433,248 bytes), `anim/anim.img` (10,688,512 bytes), and `anim/cuts.img` (270,096,384 bytes). The supplied `data.rar` contained 294 archive entries (273 files and 21 directories; about 21.0 MB unpacked), including `gta.dat`, 59 IDE files, 53 IPL files, `handling.cfg`, `vehicles.ide`, the 64 `NODES0.DAT`–`NODES63.DAT` path files, `main.scm` (3,079,744 bytes), and `script.img` (575,488 bytes). The RAR paths were checked for traversal/symlink entries before extraction. No executable or DLL entries were present in either archive.

The proprietary data files remain outside this source package and are loaded locally by the browser from the user's own game folder.

## ANP3 findings

The loose `ped.ifp` parsed as ANP3 with 294 animation clips, 7,607 bone tracks and 112,150 keyframes. All 294 clip frame-data byte counts matched their decoded content, all keyframe times were monotonic, and the parser consumed the exact declared file length with zero trailing bytes.

The `anim.img` IMG VER2 archive contained 132 entries, all `.ifp`. All 132 entries parsed as ANP3 with valid boundaries and per-animation byte totals: 1,557 clips, 38,825 tracks and 868,337 keyframes. Combined with `ped.ifp`, this is 1,851 clips, 46,432 tracks and 980,487 keyframes.

Across 980,487 keyframes the raw quaternion component scale of 1/4096 produced mean quaternion magnitude 0.999830 (minimum 0.707031, maximum 1.0). The translation scale is also 1/4096; time is 1/60 seconds. These values are confirmed against supplied real files, not just synthetic unit fixtures.

## Code changes

- Stop 24-byte fixed names at the first NUL; keep leading whitespace on bone labels.
- Decode translation components using 1/4096.
- Validate per-animation declared frame-data byte counts.
- Restrict ANP3 keyframe types to the observed `3` and `4`; do not guess a size/layout for type `2`.
- Add sampling keyed by HAnim `boneId`, the stable skeleton binding key.
- Expand synthetic tests for null-terminated fields, translation scaling, declared byte totals and bone-ID sampling.

## Known gap: cutscenes

The supplied `cuts.img` has 444 entries: 148 `.ifp`, 148 `.cut`, and 148 `.dat`. The `.ifp` entries use the legacy `ANPK` signature, not ANP3. The current ANP3 reader correctly rejects ANPK rather than treating its different chunk format as ANP3. A separately bounds-checked ANPK decoder and cutscene playback pipeline remain future work.

## Verification boundary

The actual supplied ANP3 files were scanned with an independent structural validator for this increment. The full application test suite/build still needs to run in GitHub Codespaces after applying the patch because the local development container does not have the project's npm dependencies installed.
