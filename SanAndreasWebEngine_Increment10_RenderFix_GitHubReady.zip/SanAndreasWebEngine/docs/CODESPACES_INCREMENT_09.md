# Applying the cumulative Increment 09 update in GitHub Codespaces

This patch is cumulative from the repository's Increment 07 baseline. It includes the Increment 08 IFP reader/library and the Increment 09 real-file corrections/validation notes. It does not contain `anim.rar`, `data.rar`, game assets, executables or DLLs.

From the repository root (the folder containing `SanAndreasWebEngine/`):

```bash
git switch -c feature/increment-09-real-ifp
```

Upload `SanAndreasWebEngine_Increment09_Patch.zip` to the repository root, then extract it there:

```bash
unzip -o SanAndreasWebEngine_Increment09_Patch.zip -d .
git status --short
git diff --check
git diff --stat
```

Run developer checks (these are not a gameplay play-test):

```bash
cd SanAndreasWebEngine
npm install
npm test
npm run typecheck
npm run build
```

The Codespaces Vite server uses port **4173**:

```bash
npm run dev
```

Forward port 4173 from the Codespaces **Ports** tab. This increment only indexes animation package metadata; it does not yet render CJ animation.

## Rollback

If you have not committed the feature branch, return to the original branch and delete the feature branch:

```bash
cd ..
git switch main
git branch -D feature/increment-09-real-ifp
```

Do not commit or publish proprietary files extracted from the game archives. The browser reads those files locally from your selected game folder.
