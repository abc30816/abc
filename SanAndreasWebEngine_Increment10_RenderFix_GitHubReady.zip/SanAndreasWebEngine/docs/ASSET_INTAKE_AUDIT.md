# User-supplied asset intake audit (Increment 09)

This document records metadata and parser outcomes only. It does not contain or redistribute game assets.

## Archives received

- `anim.rar`: contains `anim/ped.ifp`, `anim/anim.img`, and `anim/cuts.img`; extraction paths were checked for traversal/symlink entries before use.
- `data.rar`: 294 archive entries (273 files and 21 directories; about 21.0 MB unpacked), with game data/config/map/path/script files. No EXE or DLL entries were present.

## Parsed `data` inventory

The archive includes `data/gta.dat`, 59 IDE files, 53 IPL files, `handling.cfg`, `vehicles.ide`, `peds.ide`, 64 path node files (`NODES0.DAT` through `NODES63.DAT`), `data/script/main.scm`, and `data/script/script.img`. The `gta.dat` manifest parsed 112 resource declarations with no parser issues.

When combined with the animation folder and a placeholder executable filename for the file-indexer smoke test, the current indexer found 4 readable IMG archives (`carrec.img`, `script.img`, `anim.img`, `cuts.img`), 14,205 IDE definitions and 9,315 map placements. The only missing-resource warning was `models/cutscene.img`, which was not in the supplied archives. This synthetic folder test is not a substitute for indexing the complete installed game folder.

## Animation inventory

- `ped.ifp`: ANP3; 294 clips, 7,607 tracks, 112,150 keyframes.
- `anim/anim.img`: 132 ANP3 IFP entries; 1,557 clips, 38,825 tracks and 868,337 keyframes. All 132 packages passed declared-size and structural checks.
- `anim/cuts.img`: 444 entries; 148 ANPK `.ifp` animation packages, 148 `.cut` camera/scene files and 148 `.dat` companion files. ANPK is not treated as ANP3.

## Data handling

These archives were used only as local reference data for parser validation. No proprietary content is included in the project ZIPs or should be committed to the public GitHub repository.
