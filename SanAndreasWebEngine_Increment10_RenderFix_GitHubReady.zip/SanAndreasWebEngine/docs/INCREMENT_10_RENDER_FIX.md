# Increment 10 — world-rendering fixes and honest diagnostics

## Changes

- Removed the giant 10,000 × 10,000 green placeholder plane. It was rendered at Y=13.35, directly across the Ganton spawn area, and could cover actual map ground/road surfaces. A non-rendered fallback floor height remains in the temporary player controller only.
- Corrected GTA-to-Three.js quaternion basis conversion. Positions are mapped from GTA `(x, y, z)` to Three.js `(x, z, -y)`, which is a -90° rotation around X; object rotations must use that same basis change.
- Fixed DFF geometries without normal data. The parser previously allocated a zero-filled normal array and the renderer treated it as valid, so `computeVertexNormals()` never ran. Missing normals are now represented as an empty array and generated from mesh triangles.
- Fixed DFF geometries without texture coordinates. The parser previously supplied a zero-filled UV array, causing every vertex to sample the same texture point. A UV attribute is now attached only when the source actually has UV layers.
- A TXD parse failure no longer discards otherwise valid DFF geometry. The renderer falls back to the DFF material colors and records a warning.
- World statistics now distinguish actual drawable mesh instances from cache entries, missing DFFs, failed parses, empty/unsupported DFFs, native geometry blocks, collision meshes, and unresolved IPL IDs.
- Empty model groups are no longer added to the visible world and counted as visible instances.

## Local data validation

The supplied `data.rar` was safely unpacked as data/config files only. The TypeScript IDE/IPL/gta.dat parsers were compiled and run against those files:

- 59 IDE files and 14,212 IDE rows, giving 14,205 unique model definitions.
- 53 text IPL files and 9,315 placements.
- 112 `gta.dat` resource declarations; zero manifest parse issues.
- At the current Ganton spawn center `(2495, -1675)` and a 440-unit radius: 453 map placements, with zero unresolved IDE IDs.
- The supplied `data.rar` contains no `.img`, `.dff`, `.txd`, `.ifp`, or `.col` files. It therefore validates the map/config index, but cannot by itself validate live mesh/texture rendering. The full local `models` archives are still required for that check.

## Verification

- Standalone TypeScript compilation passed for `binary.ts`, `renderware.ts`, `dff.ts`, `ide.ts`, `ipl.ts`, and `gtaDat.ts`.
- A Node smoke test passed for synthetic RenderWare triangle DFFs both with and without UV layers; missing normals now stay absent so Three.js can compute them.
- The full app type-check, Vitest suite, and Vite production build could not run in this container because the project dependencies (`three`, `@dimforge/rapier3d-compat`, `vitest`, and `vite`) are not installed and the npm cache has no dependency set available offline. Run `npm ci`, `npm test`, and `npm run build` in Codespaces before deploying.

## Scope and safety

This package contains only source code, tests, and documentation. User-owned game archives and executables are not included. The EXE was not run, patched, unpacked, or used to bypass DRM. This is a renderer milestone, not a complete browser port: player skeleton/animation binding, full TXD coverage, LOD/interior behavior, collision response, traffic/AI, weapons, missions, audio, saves, and other gameplay systems remain incomplete.
