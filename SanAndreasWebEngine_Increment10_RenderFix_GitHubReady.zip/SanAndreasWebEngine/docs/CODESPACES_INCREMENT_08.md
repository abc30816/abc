# Applying Increment 08 in GitHub Codespaces

This patch targets the repository baseline that contains Increment 07 under `SanAndreasWebEngine/`.

1. In the Codespaces terminal, return to the repository root (the folder containing `SanAndreasWebEngine/`).
2. Create a working branch before applying the patch:

   ```bash
   git switch -c feature/increment-08-ifp-animation
   ```

3. Upload `SanAndreasWebEngine_Increment08_Patch.zip` to the repository root, then extract it there:

   ```bash
   unzip -o SanAndreasWebEngine_Increment08_Patch.zip -d .
   ```

4. Review the exact change set:

   ```bash
   git status --short
   git diff --check
   git diff --stat
   ```

5. Install the repository's pinned dependencies and run automated checks (these are developer checks, not a gameplay play-test):

   ```bash
   cd SanAndreasWebEngine
   npm install
   npm test
   npm run typecheck
   npm run build
   ```

6. Commit only after the checks finish successfully:

   ```bash
   git add README.md docs src tests
   git commit -m "Add local ANP3 IFP animation foundation"
   git push -u origin feature/increment-08-ifp-animation
   ```

## Rollback

Because this is on a separate branch, the safest full rollback is to return to the original branch and delete the feature branch:

```bash
cd ..
git switch main
git branch -D feature/increment-08-ifp-animation
```

No game assets are copied, uploaded or changed by this increment. `gta3.img` is not required for this patch; loose IFP files and IFP entries in local IMG archives are indexed from the folder selected in the browser.
