import type { GameFileSet } from '../core/GameFiles';
import { readIfpPackage } from '../core/GameFiles';
import type { IfpAnimation, IfpPackage } from '../formats/ifp';

/** Lazy local IFP package cache. It reads only the requested package and never uploads it. */
export class IfpAnimationLibrary {
  private readonly cache = new Map<string, Promise<IfpPackage>>();
  private disposed = false;

  constructor(private readonly game: GameFileSet) {}

  availablePackages(): string[] {
    const loose = [...this.game.animationFiles.keys()];
    const archived = [...this.game.animationEntries.keys()].map((key) => `img://${key}`);
    return [...new Set([...loose, ...archived])].sort();
  }

  load(packagePath: string): Promise<IfpPackage> {
    if (this.disposed) return Promise.reject(new Error('IFP animation library has been disposed'));
    const key = packagePath.replaceAll('\\', '/').replace(/^\/+/, '').toLowerCase();
    if (!key || key.length > 1_024) return Promise.reject(new TypeError('IFP package path is invalid'));
    let pending = this.cache.get(key);
    if (!pending) {
      pending = readIfpPackage(this.game, key).then((value) => {
        if (!value) throw new Error(`IFP package not found: ${packagePath}`);
        return value;
      });
      this.cache.set(key, pending);
      pending.catch(() => { if (this.cache.get(key) === pending) this.cache.delete(key); });
    }
    return pending;
  }

  async findAnimation(packagePath: string, animationName: string): Promise<IfpAnimation | null> {
    const packageData = await this.load(packagePath);
    const normalized = animationName.trim().toLowerCase();
    if (!normalized) return null;
    return packageData.animations.find((item) => item.name.toLowerCase() === normalized) ?? null;
  }

  dispose(): void {
    this.disposed = true;
    this.cache.clear();
  }
}
