import { BinaryReader } from './binary';

/**
 * Bounds-checked reader for the ANP3 IFP container used by GTA San Andreas.
 * This module decodes animation data only; it does not execute game scripts or
 * load native code.
 */
export type IfpQuaternion = readonly [x: number, y: number, z: number, w: number];
export type IfpVector3 = readonly [x: number, y: number, z: number];
export type IfpFrameKind = 'rotation' | 'rotation-translation';

export interface IfpKeyframe {
  /** Seconds from the start of this bone track. */
  timeSeconds: number;
  rotation: IfpQuaternion;
  translation: IfpVector3 | null;
}

export interface IfpSequence {
  name: string;
  boneId: number;
  frameKind: IfpFrameKind;
  frames: IfpKeyframe[];
  durationSeconds: number;
}

export interface IfpAnimation {
  name: string;
  sequences: IfpSequence[];
  declaredFrameDataSize: number;
  reservedWord: number;
}

export interface IfpPackage {
  format: 'ANP3';
  name: string;
  animations: IfpAnimation[];
  declaredEnd: number;
  trailingBytes: number;
  warnings: string[];
}

export interface IfpPose {
  rotation: IfpQuaternion;
  translation: IfpVector3 | null;
}

const HEADER_SIZE = 36;
const MAX_FILE_BYTES = 128 * 1024 * 1024;
const MAX_ANIMATIONS = 8_192;
const MAX_SEQUENCES_PER_ANIMATION = 4_096;
const MAX_TOTAL_SEQUENCES = 65_536;
const MAX_FRAMES_PER_SEQUENCE = 1_000_000;
const MAX_TOTAL_FRAMES = 5_000_000;
const MAX_DURATION_SECONDS = 24 * 60 * 60;

function fixedAscii(reader: BinaryReader, offset: number, length: number, label: string): string {
  // ANP3 fixed-width strings are C strings. Retail files can contain stale
  // exporter memory after the first NUL (for example, a 3ds Max path).
  // Preserve leading spaces in bone names; boneId is the canonical binding.
  const field = reader.slice(offset, length);
  const terminator = field.indexOf(0);
  const bytes = terminator >= 0 ? field.subarray(0, terminator) : field;
  const value = new TextDecoder('latin1').decode(bytes).replace(/[\t ]+$/g, '');
  if (!value) throw new Error(`IFP: empty ${label} at byte ${offset}`);
  return value;
}

function finite(value: number, label: string, offset: number): number {
  if (!Number.isFinite(value)) throw new Error(`IFP: non-finite ${label} at byte ${offset}`);
  return value;
}

function readQuaternion(reader: BinaryReader, offset: number): IfpQuaternion {
  const x = reader.i16(offset) / 4096;
  const y = reader.i16(offset + 2) / 4096;
  const z = reader.i16(offset + 4) / 4096;
  const w = reader.i16(offset + 6) / 4096;
  const length = Math.hypot(x, y, z, w);
  if (!Number.isFinite(length) || length < 1e-7) {
    throw new Error(`IFP: invalid zero-length quaternion at byte ${offset}`);
  }
  return [x / length, y / length, z / length, w / length];
}

function readTime(reader: BinaryReader, offset: number, previous: number): number {
  const time = finite(reader.i16(offset) / 60, 'keyframe time', offset);
  if (time < 0 || time > MAX_DURATION_SECONDS) {
    throw new Error(`IFP: keyframe time outside supported range at byte ${offset}`);
  }
  if (time < previous) throw new Error(`IFP: keyframe times are not monotonic at byte ${offset}`);
  return time;
}

/** Parse one San Andreas ANP3 animation package. ANPK cutscene packages are handled separately. */
export function parseIfpPackage(bytes: Uint8Array, label = 'IFP'): IfpPackage {
  if (!(bytes instanceof Uint8Array)) throw new TypeError('IFP: input must be Uint8Array data');
  if (bytes.byteLength > MAX_FILE_BYTES) throw new RangeError(`IFP: ${label} exceeds ${MAX_FILE_BYTES} bytes`);
  if (bytes.byteLength < HEADER_SIZE) throw new Error(`IFP: ${label} is shorter than the ANP3 header`);

  const reader = new BinaryReader(bytes, label);
  const magic = reader.ascii(0, 4);
  if (magic !== 'ANP3') {
    if (magic === 'ANPK') throw new Error('IFP: ANPK is an older container and is not supported by this San Andreas reader');
    throw new Error(`IFP: unsupported container signature "${magic}"`);
  }

  const endOffset = reader.i32(4);
  const declaredEnd = endOffset + 8;
  if (!Number.isSafeInteger(declaredEnd) || declaredEnd < HEADER_SIZE || declaredEnd > bytes.byteLength) {
    throw new Error(`IFP: invalid declared end offset ${endOffset}`);
  }

  const packageName = fixedAscii(reader, 8, 24, 'package name');
  const animationCount = reader.i32(32);
  if (animationCount < 0 || animationCount > MAX_ANIMATIONS) {
    throw new RangeError(`IFP: invalid animation count ${animationCount}`);
  }

  let cursor = HEADER_SIZE;
  let totalSequences = 0;
  let totalFrames = 0;
  const animations: IfpAnimation[] = [];

  for (let animationIndex = 0; animationIndex < animationCount; animationIndex++) {
    if (cursor + 36 > declaredEnd) throw new Error(`IFP: animation ${animationIndex} header exceeds declared end`);
    const name = fixedAscii(reader, cursor, 24, `animation ${animationIndex} name`);
    const sequenceCount = reader.i32(cursor + 24);
    const declaredFrameDataSize = reader.u32(cursor + 28);
    const reservedWord = reader.u32(cursor + 32);
    cursor += 36;

    if (sequenceCount < 0 || sequenceCount > MAX_SEQUENCES_PER_ANIMATION) {
      throw new RangeError(`IFP: animation ${name} has invalid sequence count ${sequenceCount}`);
    }
    totalSequences += sequenceCount;
    if (totalSequences > MAX_TOTAL_SEQUENCES) throw new RangeError('IFP: total sequence limit exceeded');

    const sequences: IfpSequence[] = [];
    let actualFrameDataSize = 0;
    for (let sequenceIndex = 0; sequenceIndex < sequenceCount; sequenceIndex++) {
      if (cursor + 36 > declaredEnd) throw new Error(`IFP: sequence header exceeds declared end in ${name}`);
      const sequenceName = fixedAscii(reader, cursor, 24, `sequence ${sequenceIndex} name`);
      const frameType = reader.i32(cursor + 24);
      const frameCount = reader.i32(cursor + 28);
      const boneId = reader.i32(cursor + 32);
      cursor += 36;

      if (frameCount < 0 || frameCount > MAX_FRAMES_PER_SEQUENCE) {
        throw new RangeError(`IFP: sequence ${sequenceName} has invalid frame count ${frameCount}`);
      }
      totalFrames += frameCount;
      if (totalFrames > MAX_TOTAL_FRAMES) throw new RangeError('IFP: total frame limit exceeded');

      let frameKind: IfpFrameKind;
      let frameBytes: number;
      if (frameType === 3) { frameKind = 'rotation'; frameBytes = 10; }
      else if (frameType === 4) { frameKind = 'rotation-translation'; frameBytes = 16; }
      else throw new Error(`IFP: unsupported ANP3 frame type ${frameType} in sequence ${sequenceName}`);

      const requiredBytes = frameCount * frameBytes;
      if (!Number.isSafeInteger(requiredBytes) || requiredBytes > declaredEnd - cursor) {
        throw new Error(`IFP: frame data exceeds declared end in sequence ${sequenceName}`);
      }
      actualFrameDataSize += requiredBytes;

      const frames: IfpKeyframe[] = [];
      let previousTime = 0;
      for (let frameIndex = 0; frameIndex < frameCount; frameIndex++) {
        const rotation = readQuaternion(reader, cursor);
        const timeOffset = cursor + 8;
        const timeSeconds = readTime(reader, timeOffset, previousTime);
        previousTime = timeSeconds;
        let translation: IfpVector3 | null = null;
        if (frameKind === 'rotation-translation') {
          translation = [
            finite(reader.i16(cursor + 10) / 4096, 'translation X', cursor + 10),
            finite(reader.i16(cursor + 12) / 4096, 'translation Y', cursor + 12),
            finite(reader.i16(cursor + 14) / 4096, 'translation Z', cursor + 14),
          ];
        }
        frames.push({ timeSeconds, rotation, translation });
        cursor += frameBytes;
      }
      sequences.push({
        name: sequenceName,
        boneId,
        frameKind,
        frames,
        durationSeconds: previousTime,
      });
    }
    if (actualFrameDataSize !== declaredFrameDataSize) {
      throw new Error(`IFP: animation ${name} declares ${declaredFrameDataSize} frame-data bytes but contains ${actualFrameDataSize}`);
    }
    animations.push({ name, sequences, declaredFrameDataSize, reservedWord });
  }

  if (cursor > declaredEnd) throw new Error('IFP: decoded records exceed declared end');
  const trailingBytes = declaredEnd - cursor;
  const warnings: string[] = [];
  if (trailingBytes > 0) warnings.push(`${trailingBytes} unparsed byte(s) remain before the declared ANP3 end`);

  return { format: 'ANP3', name: packageName, animations, declaredEnd, trailingBytes, warnings };
}

function normalizeQuaternion(q: readonly number[]): IfpQuaternion {
  const length = Math.hypot(q[0], q[1], q[2], q[3]);
  if (!Number.isFinite(length) || length < 1e-8) return [0, 0, 0, 1];
  return [q[0] / length, q[1] / length, q[2] / length, q[3] / length];
}

function slerp(a: IfpQuaternion, bInput: IfpQuaternion, t: number): IfpQuaternion {
  let bx = bInput[0], by = bInput[1], bz = bInput[2], bw = bInput[3];
  let dot = a[0] * bx + a[1] * by + a[2] * bz + a[3] * bw;
  if (dot < 0) { dot = -dot; bx = -bx; by = -by; bz = -bz; bw = -bw; }
  if (dot > 0.9995) return normalizeQuaternion([
    a[0] + t * (bx - a[0]), a[1] + t * (by - a[1]),
    a[2] + t * (bz - a[2]), a[3] + t * (bw - a[3]),
  ]);
  const theta = Math.acos(Math.max(-1, Math.min(1, dot)));
  const sinTheta = Math.sin(theta);
  if (Math.abs(sinTheta) < 1e-8) return a;
  const wa = Math.sin((1 - t) * theta) / sinTheta;
  const wb = Math.sin(t * theta) / sinTheta;
  return normalizeQuaternion([
    a[0] * wa + bx * wb, a[1] * wa + by * wb,
    a[2] * wa + bz * wb, a[3] * wa + bw * wb,
  ]);
}

/** Sample a decoded sequence. Opaque frame sequences return null until decoded. */
export function sampleIfpSequence(sequence: IfpSequence, timeSeconds: number, loop = false): IfpPose | null {
  if (!Number.isFinite(timeSeconds)) throw new TypeError('IFP sampler time must be finite');
  const frames = sequence.frames;
  if (frames.length === 0) return null;

  const firstTime = frames[0].timeSeconds;
  const lastTime = frames[frames.length - 1].timeSeconds;
  const duration = Math.max(0, lastTime - firstTime);
  let time = timeSeconds;
  if (loop && duration > 0) time = firstTime + (((time - firstTime) % duration) + duration) % duration;
  else time = Math.max(firstTime, Math.min(lastTime, time));

  let low = 0, high = frames.length - 1;
  while (low < high) {
    const mid = (low + high) >>> 1;
    if (frames[mid].timeSeconds < time) low = mid + 1;
    else high = mid;
  }
  const rightIndex = low;
  if (rightIndex === 0 || frames[rightIndex].timeSeconds === time) {
    const frame = frames[rightIndex];
    return { rotation: frame.rotation, translation: frame.translation };
  }
  const left = frames[rightIndex - 1];
  const right = frames[rightIndex];
  const span = right.timeSeconds - left.timeSeconds;
  const alpha = span > 0 ? Math.max(0, Math.min(1, (time - left.timeSeconds) / span)) : 0;
  let translation: IfpVector3 | null = null;
  if (left.translation && right.translation) {
    translation = [
      left.translation[0] + (right.translation[0] - left.translation[0]) * alpha,
      left.translation[1] + (right.translation[1] - left.translation[1]) * alpha,
      left.translation[2] + (right.translation[2] - left.translation[2]) * alpha,
    ];
  } else {
    translation = alpha < 0.5 ? left.translation : right.translation;
  }
  return { rotation: slerp(left.rotation, right.rotation, alpha), translation };
}

/** Sample every decoded bone sequence in an animation, keyed by normalized bone name. */
export function sampleIfpAnimation(animation: IfpAnimation, timeSeconds: number, loop = false): Map<string, IfpPose> {
  const pose = new Map<string, IfpPose>();
  for (const sequence of animation.sequences) {
    const sampled = sampleIfpSequence(sequence, timeSeconds, loop);
    if (sampled) pose.set(sequence.name.toLowerCase(), sampled);
  }
  return pose;
}


/** Sample an animation using GTA HAnim node IDs, the stable skeleton binding key. */
export function sampleIfpAnimationByBoneId(animation: IfpAnimation, timeSeconds: number, loop = false): Map<number, IfpPose> {
  const pose = new Map<number, IfpPose>();
  for (const sequence of animation.sequences) {
    const sampled = sampleIfpSequence(sequence, timeSeconds, loop);
    if (sampled) pose.set(sequence.boneId, sampled);
  }
  return pose;
}
