import * as THREE from 'three';
import type { GameFileSet } from '../core/GameFiles';
import { readModelDff, readTextureDictionary } from '../core/GameFiles';
import { buildCollisionMesh, buildDffObject, gtaPositionToThree, gtaQuaternionToThree } from './DffObject';

interface WorldChunk {
  key: string;
  group: THREE.Group;
  loaded: boolean;
  loading: boolean;
  instances: GameFileSet['instances'];
}

type ModelStatus = 'pending' | 'missing' | 'failed' | 'loaded' | 'empty';
interface ModelDiagnostic {
  status: ModelStatus;
  drawableMeshes: number;
  nativeGeometries: number;
  warnings: string[];
}

export interface StreamStats {
  activeChunks: number;
  visibleInstances: number;
  renderedMeshes: number;
  collisionMeshes: number;
  cachedModels: number;
  loadedModels: number;
  missingModels: number;
  failedModels: number;
  emptyModels: number;
  nativeGeometrySkips: number;
  modelWarnings: number;
  unresolvedInstances: number;
}

export class WorldStreamer {
  readonly root = new THREE.Group();
  private readonly chunks = new Map<string, WorldChunk>();
  private readonly modelCache = new Map<string, Promise<THREE.Group | null>>();
  private readonly textureCache = new Map<string, Promise<Map<string, THREE.Texture>>>();
  private readonly modelDiagnostics = new Map<string, ModelDiagnostic>();
  private readonly byChunk = new Map<string, GameFileSet['instances']>();
  private readonly chunkSize = 180;
  private readonly radius = 440;

  constructor(private readonly game: GameFileSet) {
    this.root.name = 'streamed-world';
    for (const item of game.instances) {
      const cx = Math.floor(item.position[0] / this.chunkSize);
      const cz = Math.floor(item.position[1] / this.chunkSize);
      const key = `${cx}:${cz}`;
      const list = this.byChunk.get(key) ?? [];
      list.push(item);
      this.byChunk.set(key, list);
    }
  }

  async update(player: THREE.Vector3): Promise<void> {
    const gtaX = player.x;
    const gtaY = -player.z;
    const cx = Math.floor(gtaX / this.chunkSize);
    const cz = Math.floor(gtaY / this.chunkSize);
    const r = Math.ceil(this.radius / this.chunkSize);
    const wanted = new Set<string>();
    const candidates: WorldChunk[] = [];
    for (let x = cx - r; x <= cx + r; x++) {
      for (let z = cz - r; z <= cz + r; z++) {
        const centerX = (x + 0.5) * this.chunkSize;
        const centerZ = (z + 0.5) * this.chunkSize;
        if (Math.hypot(centerX - gtaX, centerZ - gtaY) > this.radius + this.chunkSize * 0.8) continue;
        const key = `${x}:${z}`;
        const instances = this.byChunk.get(key);
        if (!instances?.length) continue;
        wanted.add(key);
        let chunk = this.chunks.get(key);
        if (!chunk) {
          chunk = { key, group: new THREE.Group(), loaded: false, loading: false, instances };
          chunk.group.name = `world-cell-${key}`;
          this.chunks.set(key, chunk);
          this.root.add(chunk.group);
        }
        if (!chunk.loaded && !chunk.loading) candidates.push(chunk);
      }
    }
    for (const [key, chunk] of this.chunks) {
      if (!wanted.has(key)) { this.root.remove(chunk.group); this.chunks.delete(key); }
    }
    // Load a small number of cells at a time to avoid a long main-thread stall.
    await Promise.all(candidates.slice(0, 2).map((chunk) => this.loadChunk(chunk)));
  }

  private async loadChunk(chunk: WorldChunk): Promise<void> {
    chunk.loading = true;
    let renderedInstances = 0;
    let collisionCount = 0;
    let renderedMeshCount = 0;
    let unresolvedInstances = 0;
    try {
      for (const instance of chunk.instances) {
        const def = this.game.ide.get(instance.id);
        const modelName = (def?.modelName ?? instance.modelName).toLowerCase();
        const txdName = (def?.txdName ?? '').toLowerCase();
        if (!modelName) { unresolvedInstances++; continue; }

        const model = await this.getModel(modelName, txdName);
        const collisionModel = this.game.collisions.get(modelName);
        const collision = collisionModel ? buildCollisionMesh(collisionModel) : null;
        if (collision) {
          collision.position.copy(gtaPositionToThree(instance.position));
          collision.quaternion.copy(gtaQuaternionToThree(instance.rotation));
          chunk.group.add(collision);
          collisionCount++;
        }

        // A parsed DFF can contain frames/atomics but no drawable triangles (for example,
        // an unsupported native pipeline). Do not add an empty Group and call it visible.
        if (!model || Number(model.userData.drawableMeshCount ?? 0) === 0) continue;
        const object = model.clone(true);
        object.position.copy(gtaPositionToThree(instance.position));
        object.quaternion.copy(gtaQuaternionToThree(instance.rotation));
        const distance = def?.drawDistance ?? 120;
        object.userData.drawDistance = distance;
        object.userData.modelName = modelName;
        chunk.group.add(object);
        renderedInstances++;
        renderedMeshCount += Number(model.userData.drawableMeshCount ?? 0);
      }
      chunk.loaded = true;
      chunk.group.userData.renderedInstances = renderedInstances;
      chunk.group.userData.renderedMeshes = renderedMeshCount;
      chunk.group.userData.collisionMeshes = collisionCount;
      chunk.group.userData.unresolvedInstances = unresolvedInstances;
    } finally {
      chunk.loading = false;
    }
  }

  private getModel(name: string, txdName: string): Promise<THREE.Group | null> {
    const cacheKey = `${name}|${txdName}`;
    let result = this.modelCache.get(cacheKey);
    if (!result) {
      this.modelDiagnostics.set(cacheKey, { status: 'pending', drawableMeshes: 0, nativeGeometries: 0, warnings: [] });
      result = (async () => {
        const diagnostic = this.modelDiagnostics.get(cacheKey)!;
        try {
          const data = await readModelDff(this.game, name);
          if (!data) {
            diagnostic.status = 'missing';
            diagnostic.warnings.push(`DFF not found: ${name}.dff`);
            return null;
          }

          // A missing or malformed TXD must not suppress otherwise valid DFF geometry.
          let textures = new Map<string, THREE.Texture>();
          if (txdName) {
            try {
              textures = await this.getTextures(txdName);
              if (textures.size === 0) diagnostic.warnings.push(`No decoded textures found in ${txdName}.txd; material colors will be used.`);
            } catch (error) {
              diagnostic.warnings.push(`TXD ${txdName} failed: ${(error as Error).message}`);
              console.warn(`Texture dictionary ${txdName}.txd could not be decoded; rendering ${name}.dff with material colors.`, error);
            }
          }

          const object = buildDffObject(data, name, textures);
          diagnostic.drawableMeshes = Number(object.userData.drawableMeshCount ?? 0);
          diagnostic.nativeGeometries = Number(object.userData.nativeGeometryCount ?? 0);
          diagnostic.warnings.push(...((object.userData.warnings as string[] | undefined) ?? []));
          diagnostic.status = diagnostic.drawableMeshes > 0 ? 'loaded' : 'empty';
          if (diagnostic.status === 'empty') {
            diagnostic.warnings.push('DFF parsed but produced no drawable meshes.');
          }
          return object;
        } catch (error) {
          diagnostic.status = 'failed';
          diagnostic.warnings.push((error as Error).message || String(error));
          console.warn(`Could not load ${name}.dff`, error);
          return null;
        }
      })();
      this.modelCache.set(cacheKey, result);
    }
    return result;
  }

  private getTextures(name: string): Promise<Map<string, THREE.Texture>> {
    let result = this.textureCache.get(name);
    if (!result) {
      result = (async () => {
        const decoded = await readTextureDictionary(this.game, name);
        const textures = new Map<string, THREE.Texture>();
        for (const [key, item] of decoded ?? []) {
          const texture = new THREE.DataTexture(item.rgba, item.width, item.height, THREE.RGBAFormat, THREE.UnsignedByteType);
          texture.colorSpace = THREE.SRGBColorSpace;
          texture.wrapS = THREE.RepeatWrapping; texture.wrapT = THREE.RepeatWrapping;
          texture.magFilter = THREE.LinearFilter; texture.minFilter = THREE.LinearMipmapLinearFilter;
          texture.generateMipmaps = true; texture.flipY = true; texture.needsUpdate = true;
          texture.userData.hasAlpha = item.hasAlpha;
          textures.set(key, texture);
        }
        return textures;
      })();
      this.textureCache.set(name, result);
    }
    return result;
  }

  getStats(): StreamStats {
    let visibleInstances = 0;
    let renderedMeshes = 0;
    let collisionMeshes = 0;
    let unresolvedInstances = 0;
    for (const chunk of this.chunks.values()) {
      visibleInstances += Number(chunk.group.userData.renderedInstances ?? 0);
      renderedMeshes += Number(chunk.group.userData.renderedMeshes ?? 0);
      collisionMeshes += Number(chunk.group.userData.collisionMeshes ?? 0);
      unresolvedInstances += Number(chunk.group.userData.unresolvedInstances ?? 0);
    }

    let loadedModels = 0, missingModels = 0, failedModels = 0, emptyModels = 0;
    let nativeGeometrySkips = 0, modelWarnings = 0;
    for (const diagnostic of this.modelDiagnostics.values()) {
      if (diagnostic.status === 'loaded') loadedModels++;
      else if (diagnostic.status === 'missing') missingModels++;
      else if (diagnostic.status === 'failed') failedModels++;
      else if (diagnostic.status === 'empty') emptyModels++;
      nativeGeometrySkips += diagnostic.nativeGeometries;
      if (diagnostic.warnings.length) modelWarnings++;
    }

    return {
      activeChunks: this.chunks.size,
      visibleInstances,
      renderedMeshes,
      collisionMeshes,
      cachedModels: this.modelCache.size,
      loadedModels,
      missingModels,
      failedModels,
      emptyModels,
      nativeGeometrySkips,
      modelWarnings,
      unresolvedInstances,
    };
  }
}
