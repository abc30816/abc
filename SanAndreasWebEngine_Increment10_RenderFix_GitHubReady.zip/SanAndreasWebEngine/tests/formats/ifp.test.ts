import { describe, expect, it } from 'vitest';
import { parseIfpPackage, sampleIfpAnimation, sampleIfpAnimationByBoneId, sampleIfpSequence } from '../../src/formats/ifp';

function fixed(value: string, length: number): Uint8Array {
  const out = new Uint8Array(length);
  out.set(new TextEncoder().encode(value).subarray(0, length));
  return out;
}

function buildAnp3(options: {
  packageName?: string;
  animationName?: string;
  sequences?: Array<{
    name: string;
    type: number;
    boneId: number;
    frames: Array<{ rotation?: [number, number, number, number]; time?: number; translation?: [number, number, number] }>;
  }>;
} = {}): Uint8Array {
  const sequences = options.sequences ?? [];
  const parts: Uint8Array[] = [];
  const header = new Uint8Array(36);
  header.set(fixed('ANP3', 4), 0);
  header.set(fixed(options.packageName ?? 'ped', 24), 8);
  new DataView(header.buffer).setInt32(32, 1, true);
  parts.push(header);

  const animation = new Uint8Array(36);
  animation.set(fixed(options.animationName ?? 'walk', 24), 0);
  const av = new DataView(animation.buffer);
  av.setInt32(24, sequences.length, true);
  const frameDataSize = sequences.reduce((total, sequence) => total + sequence.frames.length * (sequence.type === 4 ? 16 : 10), 0);
  av.setUint32(28, frameDataSize, true);
  av.setUint32(32, 0, true);
  parts.push(animation);

  for (const sequence of sequences) {
    const sh = new Uint8Array(36);
    sh.set(fixed(sequence.name, 24), 0);
    const sv = new DataView(sh.buffer);
    sv.setInt32(24, sequence.type, true);
    sv.setInt32(28, sequence.frames.length, true);
    sv.setInt32(32, sequence.boneId, true);
    parts.push(sh);
    for (const frame of sequence.frames) {
      const frameBytes = new Uint8Array(sequence.type === 4 ? 16 : 10);
      const view = new DataView(frameBytes.buffer);
      const q = frame.rotation ?? [0, 0, 0, 4096];
      q.forEach((value, index) => view.setInt16(index * 2, value, true));
      view.setInt16(8, frame.time ?? 0, true);
      if (sequence.type === 4) {
        const t = frame.translation ?? [0, 0, 0];
        t.forEach((value, index) => view.setInt16(10 + index * 2, value, true));
      }
      parts.push(frameBytes);
    }
  }

  const length = parts.reduce((sum, part) => sum + part.length, 0);
  const out = new Uint8Array(length);
  let offset = 0;
  for (const part of parts) { out.set(part, offset); offset += part.length; }
  new DataView(out.buffer).setInt32(4, out.length - 8, true);
  return out;
}

describe('San Andreas ANP3 IFP reader', () => {
  it('decodes compressed root and child tracks and samples a blended pose', () => {
    const bytes = buildAnp3({ sequences: [
      { name: 'root', type: 4, boneId: 0, frames: [
        { time: 0, translation: [0, 0, 0] },
        { time: 60, translation: [2048, 0, 0] },
      ] },
      { name: 'bip01_l_forearm', type: 3, boneId: 22, frames: [
        { time: 0, rotation: [0, 0, 0, 4096] },
        { time: 60, rotation: [0, 0, 2896, 2896] },
      ] },
    ] });
    const parsed = parseIfpPackage(bytes, 'ped.ifp');
    expect(parsed.format).toBe('ANP3');
    expect(parsed.name).toBe('ped');
    expect(parsed.animations[0].name).toBe('walk');
    expect(parsed.animations[0].sequences).toHaveLength(2);

    const rootPose = sampleIfpSequence(parsed.animations[0].sequences[0], 0.5);
    expect(rootPose?.translation?.[0]).toBeCloseTo(0.5, 5);
    expect(rootPose?.rotation[3]).toBeCloseTo(1, 5);

    const all = sampleIfpAnimation(parsed.animations[0], 0.5);
    expect(all.has('root')).toBe(true);
    expect(all.has('bip01_l_forearm')).toBe(true);
    expect(Math.hypot(...all.get('bip01_l_forearm')!.rotation)).toBeCloseTo(1, 5);
    const byBone = sampleIfpAnimationByBoneId(parsed.animations[0], 0.5);
    expect(byBone.has(0)).toBe(true);
    expect(byBone.has(22)).toBe(true);
  });


  it('loops over the decoded clip duration and clamps non-looping samples', () => {
    const parsed = parseIfpPackage(buildAnp3({ sequences: [
      { name: 'root', type: 4, boneId: 0, frames: [
        { time: 60, translation: [0, 0, 0] },
        { time: 120, translation: [4096, 0, 0] },
      ] },
    ] }));
    const track = parsed.animations[0].sequences[0];
    expect(sampleIfpSequence(track, 100)?.translation?.[0]).toBeCloseTo(1, 5);
    expect(sampleIfpSequence(track, 2, true)?.translation?.[0]).toBeCloseTo(0, 5);
    expect(sampleIfpSequence(track, 99)?.translation?.[0]).toBeCloseTo(1, 5);
  });

  it('rejects unsupported signatures, invalid frame kinds, bad timing and truncated payloads', () => {
    expect(() => parseIfpPackage(new TextEncoder().encode('ANPK' + 'x'.repeat(40)))).toThrow(/ANPK/);
    const unsupported = buildAnp3({ sequences: [{ name: 'bad', type: 9, boneId: 0, frames: [] }] });
    expect(() => parseIfpPackage(unsupported)).toThrow(/unsupported ANP3 frame type/);
    const nonMonotonic = buildAnp3({ sequences: [{ name: 'bad_time', type: 3, boneId: 0, frames: [{ time: 60 }, { time: 30 }] }] });
    expect(() => parseIfpPackage(nonMonotonic)).toThrow(/not monotonic/);
    const truncated = buildAnp3({ sequences: [{ name: 'short', type: 3, boneId: 0, frames: [{ time: 0 }] }] }).slice(0, -1);
    expect(() => parseIfpPackage(truncated)).toThrow(/declared end|invalid declared end/);
  });

  it('stops fixed-width names at the first NUL while preserving real bone IDs', () => {
    const bytes = buildAnp3({ sequences: [
      { name: ' Pelvis', type: 3, boneId: 1, frames: [{ time: 0 }] },
    ] });
    bytes.set(new TextEncoder().encode('walk\0=C:=C:\\3dsmax5'), 36);
    const parsed = parseIfpPackage(bytes);
    expect(parsed.animations[0].name).toBe('walk');
    expect(parsed.animations[0].sequences[0].name).toBe(' Pelvis');
    expect(parsed.animations[0].sequences[0].boneId).toBe(1);
  });

  it('rejects a mismatch between the declared per-animation frame-data size and decoded frames', () => {
    const bytes = buildAnp3({ sequences: [
      { name: 'root', type: 3, boneId: 0, frames: [{ time: 0 }] },
    ] });
    new DataView(bytes.buffer).setUint32(64, 0, true);
    expect(() => parseIfpPackage(bytes)).toThrow(/declares 0 frame-data bytes but contains 10/);
  });

});
