import { describe, expect, it } from 'vitest';
import * as THREE from 'three';
import { gtaPositionToThree, gtaQuaternionToThree } from '../../src/world/DffObject';

describe('GTA to Three.js world coordinates', () => {
  it('maps GTA Z-up positions into Three.js Y-up coordinates', () => {
    expect(gtaPositionToThree([1, 2, 3]).toArray()).toEqual([1, 3, -2]);
  });

  it('conjugates a GTA Y-axis rotation into the converted Three.js basis', () => {
    const half = Math.SQRT1_2;
    const rotation = gtaQuaternionToThree([0, half, 0, half]);
    const transformed = new THREE.Vector3(1, 0, 0).applyQuaternion(rotation);
    expect(transformed.x).toBeCloseTo(0, 6);
    expect(transformed.y).toBeCloseTo(-1, 6);
    expect(transformed.z).toBeCloseTo(0, 6);
  });
});
