import { describe, expect, it } from 'vitest';
import { indexGameFolder } from '../../src/core/GameFiles';
import { IfpAnimationLibrary } from '../../src/animation/IfpAnimationLibrary';

function localFile(path: string, bytes: Uint8Array | string): File {
  const file = new File([bytes], path.split('/').at(-1) ?? 'file.bin');
  Object.defineProperty(file, 'webkitRelativePath', { value: path });
  return file;
}

function emptyAnp3(name = 'ped'): Uint8Array {
  const bytes = new Uint8Array(36);
  bytes.set(new TextEncoder().encode('ANP3'), 0);
  bytes.set(new TextEncoder().encode(name), 8);
  new DataView(bytes.buffer).setInt32(4, bytes.length - 8, true);
  return bytes;
}

describe('local IFP animation library', () => {
  it('loads an IFP package directly from an IMG archive entry', async () => {
    const archive = new Uint8Array(4096);
    const view = new DataView(archive.buffer);
    archive.set(new TextEncoder().encode('VER2'), 0);
    view.setUint32(4, 1, true);
    view.setUint32(8, 1, true);
    view.setUint16(12, 1, true);
    view.setUint16(14, 1, true);
    archive.set(new TextEncoder().encode('ped.ifp'), 16);
    archive.set(emptyAnp3(), 2048);
    const game = await indexGameFolder([
      localFile('SA/gta_sa.exe', 'MZ'),
      localFile('SA/models/anim.img', archive),
    ]);
    const library = new IfpAnimationLibrary(game);
    expect(library.availablePackages()).toContain('img://anim.img:ped.ifp');
    const packageData = await library.load('img://anim.img:ped.ifp');
    expect(packageData.name).toBe('ped');
    library.dispose();
  });

  it('indexes and loads a loose animation package lazily by relative path', async () => {
    const img = new Uint8Array(8);
    img.set(new TextEncoder().encode('VER2'));
    const game = await indexGameFolder([
      localFile('SA/gta_sa.exe', 'MZ'),
      localFile('SA/models/gta3.img', img),
      localFile('SA/anim/ped.ifp', emptyAnp3()),
    ]);
    const library = new IfpAnimationLibrary(game);
    expect(library.availablePackages()).toEqual(['anim/ped.ifp']);
    const packageData = await library.load('anim/ped.ifp');
    expect(packageData.name).toBe('ped');
    library.dispose();
    await expect(library.load('anim/ped.ifp')).rejects.toThrow(/disposed/);
  });
});
