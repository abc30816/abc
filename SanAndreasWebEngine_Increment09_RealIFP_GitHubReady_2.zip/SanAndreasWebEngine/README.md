# San Andreas Web Engine — independent browser runtime

This is a clean, independently written browser-engine project. It is **not a fork of OpenSA**, does not import OpenSA source, and does not bundle GTA executable code or game assets. It uses only general engine ideas: local-only asset access, spatial world cells, a renderer/streamer split, and isolated gameplay systems.

## What this milestone actually does

- Runs as an independently written browser application using TypeScript, Vite and Three.js/WebGL.
- Reads the selected game directory locally in the browser. It does not upload game files to a server.
- Parses `data/gta.dat` into a bounded resource manifest, prioritizes its IMG/CDIMAGE archives, and reports missing declared resources.
- Indexes San Andreas IMG VER2 archives and paired `.dir`/`.img` archives, keeping large archive entries lazy until requested. Direct mission files and SCM entries inside IMG archives are indexed separately.
- Parses text-format IDE definitions, text IPL `inst` placements, and binary `bnry` streaming IPL instances stored inside IMG archives.
- Walks bounded RenderWare chunk streams and parses a first subset of non-native DFF clump/frame/geometry/atomic data, including material lists and BinMesh triangle-list/triangle-strip indices.
- Decodes a first PC D3D9 TXD subset: DXT1–DXT5 and common raw 16/24/32-bit and luminance formats. The base mip is uploaded; remaining mip levels are bounds-checked and WebGL generates its own mip chain.
- Parses COL2/COL3 compressed triangle meshes and uses them as invisible collision surfaces for the prototype ground raycast.
- Builds a spatial grid and incrementally loads nearby map placements around the Ganton start area.
- Provides a basic third-person movement/camera harness (WASD, mouse look, sprint, jump).
- Includes synthetic fixture tests for IMG, IDE/IPL, RenderWare boundaries, COL3, DXT1 decoding, vehicle configuration, handling-driven vehicle dynamics and the ANP3 IFP animation reader/sampler.

This is original implementation code. It does not import or fork OpenSA, and it does not contain Rockstar code or assets.

## New in Increment 07: first integrated vehicle-driving loop

- Loads `vehicles.ide` and `handling.cfg` from the user-selected local folder and joins definitions by model/handling ID.
- Selects up to eight nearby car models that are actually present in the user's IMG index; no fake placeholder car is substituted when a DFF cannot be decoded.
- Loads each selected DFF and its TXD locally, with texture/material lifetime cleanup on exit.
- Adds proximity-based enter (`E`) and exit (`F`), throttle/reverse (`W`/`S`), steering (`A`/`D`), service brake (`Space`), handbrake (`Shift`), speed/gear/body HUD and a chase camera.
- Applies a first-pass bicycle/arcade dynamics model based on parsed mass, acceleration, max velocity, braking, traction, steering lock, engine inertia and gear count.
- World streaming follows the active vehicle rather than the hidden on-foot player.

This is a first vehicle gameplay slice, not a full SA vehicle implementation. It does not yet include wheel contact, suspension, per-wheel grip, vehicle collisions, deformation, lights, doors, bikes/boats/planes/helis/trains or traffic AI. The handling-to-SI conversion is deliberately isolated for later calibration against in-game reference measurements.

## Animation data foundation (Increments 08–09)

- Indexes loose `anim/*.ifp` packages and `.ifp` entries in IMG archives.
- Decodes San Andreas `ANP3` package headers, animation sequences, compressed rotation tracks and root rotation/translation tracks.
- Decodes only the two ANP3 frame types confirmed in the supplied files (type 3 rotation, type 4 rotation + translation); unknown frame types are rejected safely rather than assigned a guessed layout.
- Adds quaternion/translation keyframe sampling for later skeleton integration.
- This does not yet skin or animate a DFF character; DFF Skin/HAnim extraction and bone binding remain required.

## Real-file ANP3 animation validation (Increment 09)

The ANP3 decoder was checked against the user-supplied retail-format samples without adding those copyrighted game files to this repository:

- `anim/ped.ifp`: 294 clips, 7,607 bone tracks and 112,150 keyframes; all per-clip frame-byte totals matched and the read cursor ended exactly at the declared EOF.
- `anim/anim.img`: all 132 indexed IFP entries had valid ANP3 signatures and passed the same structural checks; 1,557 clips, 38,825 tracks and 868,337 keyframes were decoded.
- Combined: 1,851 clips, 46,432 tracks and 980,487 keyframes.
- Compressed quaternions had a measured mean length of 0.999830 before normalization. Root translation uses the verified 1/4096 scale; keyframe time uses 1/60 seconds.

The parser now stops fixed-width names at the first NUL (retail exporter garbage can follow it), preserves leading whitespace in track labels, verifies each animation's declared frame-data byte total, and exposes pose sampling by HAnim bone ID. This is structural/format validation, not yet proof that a skinned CJ model renders correctly.

The uploaded `anim/cuts.img` contains 148 cutscene IFP files with the older `ANPK` signature, plus 148 matching `.cut` and 148 `.dat` files. ANPK decoding and the cutscene camera/model pipeline are not implemented in this increment. Those files are not copied into this repository.

## Important: this is not the complete GTA game yet

This milestone is **not yet the complete San Andreas game**. It is an early asset-rendering, on-foot movement and first car-driving prototype with an IFP animation data reader, not a mission-playable release. It does not yet implement the SCM mission interpreter, cinematic/cutscene pipeline, CJ skin/clothing and IFP skeletal animation, pedestrian/traffic spawning and AI, weapons and character damage, full vehicle classes and physics, interior/portal streaming, complete rigid-body collision and surface response, radio/music and speech, compatible save games, or the complete HUD/radar/pickup systems. Native DFF geometry (including many platform-instanced meshes), skin/HAnim plugins, paletted TXD entries, COL1 shapes, and several RenderWare extensions remain unsupported. Real ANP3 animation packages were structurally validated against the supplied game data; full model/skeleton/world compatibility has not yet been validated. Some models may be missing, incorrectly oriented, untextured or collide imperfectly.

The original game's exact gameplay cannot be honestly claimed until these systems are implemented and tested against a legitimate game copy. The code is structured so they can be added as independent subsystems.

## Run locally

Use Node.js 20.19+ (Node 22 recommended):

```bash
npm install
npm run dev
```

This repository pins the development server to `0.0.0.0:4173` (`vite.config.ts`, `strictPort: true`). In GitHub Codespaces, forward port **4173** from the Ports tab. Open the Vite address in Chromium/Chrome and select the main folder containing `gta_sa.exe` (the folder should also contain `models/`, `data/`, `anim/` and `audio/`). Use the directory picker; do not select the entire Windows drive.

Build and tests:

```bash
npm test
npm run typecheck
npm run build
```


## Validation status

Offline verification for this increment: the local resource parsers, `GameFiles` indexer, vehicle configuration parsers and pure vehicle-dynamics module passed strict TypeScript compilation. Deterministic checks passed for GTA.DAT resource linking, path-traversal rejection, IMG script-entry discovery, acceleration, displacement, braking, steering and damage clamping. The changed application files passed a TypeScript syntax/transpile-only pass. The full Vitest suite, full application typecheck and Vite production build could not be run here: dependencies were absent and npm registry DNS/network access was unavailable. These checks still need to be run in Codespaces before deployment; synthetic fixtures are not a substitute for retail-file compatibility tests.

Increment 08–09 offline verification: `ifp.ts`, `GameFiles.ts`, `IfpAnimationLibrary.ts` and their format dependencies passed strict standalone TypeScript compilation. A Node smoke test using the supplied local files indexed 4 IMG archives, 14,205 IDE definitions and 9,315 map placements; it decoded `ped.ifp` and all 132 ANP3 packages in `anim.img` with zero ANP3 parse failures. The synthetic Vitest fixtures and full Vite application build still need to run in Codespaces because the full dependency set was not installed in this working environment.

## Coordinate and asset notes

The runtime converts the game's Z-up world coordinates to the renderer's Y-up coordinates. RenderWare chunks are length-checked before parsing. IMG entry data is read lazily from `Blob.slice()` so the browser does not need to copy every large archive into memory at startup.

The DFF reader currently supports non-native geometry and the BinMesh material splits. TXD decoding is wired into material construction for the supported D3D9 formats. Native DFF data and paletted TXD formats still need dedicated decoders; no claim is made that every retail model will render yet.

## Planned engineering stages

1. Extend the successful `gta.dat`/IMG/IDE/IPL check to the full local installation; finish remaining IPL sections and duplicate/LOD pairing rules.
2. Complete PC DFF coverage, including native geometry, Skin/HAnim skeleton extraction, bone binding, 2dfx and material plugins; connect the now real-file-validated ANP3 sampler to those skeletons and implement ANPK cutscene packages separately.
3. Complete TXD palettes, mip/alpha rules and the remaining PC raster variants; validate textures against retail samples.
4. Upgrade COL2/COL3/COL1 and the player capsule to a proper fixed-step collision and surface-response system; extend the first vehicle slice with wheel contact, suspension, impact collision and vehicle classes.
5. Implement ped models, IFP animation, CJ components/clothing, vehicle parts and entry/exit/handling.
6. Add traffic and pedestrian task/AI, weapons, health, HUD/radar, pickups, interiors, day/weather, and audio/radio.
7. Implement the correct San Andreas SCM bytecode/runtime and mission state, then validate story progression and save/load against a clean supported PC data set.
8. Performance work: worker-based asset decoding, progressive streaming, GPU texture compression, cache persistence and mobile/desktop input profiles.

## Legal / distribution boundary

This repository contains only original engine code. It does not include Rockstar/Take-Two executables, scripts, models, maps, textures, radio audio, or other copyrighted game data. The user supplies their own legitimate installation locally. Do not commit or publish game files, extracted assets, or proprietary executable code.
